INSERT INTO source3.measurement_types ("name",unit,description,"statisticalType") VALUES
	 ('PM10','g/km/h','polveri sottili','Mean'),
	 ('NOX','g/km/h','Ossidi di azoto',NULL),
	 ('temp_aria','[°C]','Temperatura dell’aria','Mean'),
	 ('umidita_rel','[%]','Umidità relativa dell’aria','Mean'),
	 ('umidita_abs','[g/m^3]','Umidità assoluta dell’aria','Mean'),
	 ('Ozono','µg/m³','Valori a 10 minuti','Mean'),
	 ('wind-direction','° ','Direzione del vento',NULL),
	 ('wind-speed','m/s','Velocità del vento',NULL),
	 ('water-temperature','°C','Temperatura acqua',NULL),
	 ('wind10m_speed','m/s',NULL,NULL);
INSERT INTO source3.measurement_types ("name",unit,description,"statisticalType") VALUES
	 ('wind10m_direction','gN',NULL,NULL);